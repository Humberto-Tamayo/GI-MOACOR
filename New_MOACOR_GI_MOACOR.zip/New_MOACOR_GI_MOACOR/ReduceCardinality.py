"""
Reduce cardinality.
"""

import numpy as np

from Public.DissimilarityMatrix import dissimilarityMatrix



def reduceCardinality(ppf, scheme, problem, m, N):
    """Reduces the cardinality of the Pareto front for a given problem"""
    #A = np.genfromtxt('ParetoFronts/'+problem+'_{0:0=2d}D'.format(m)+'.pof')
    A = problem
    if scheme == 'INCLUSION':
        A = fastGreedyInclusionAlgorithm(A, N, ppf)
    elif scheme == 'REMOVAL':
        A = fastGreedyRemovalAlgorithm(A, N, ppf)
    elif scheme == 'STEADY':
        A = fastSteadyStateRemovalAlgorithm(A, N, ppf)
    return A

def fastGreedyInclusionAlgorithm(A, N, ppf):
    """Selects N solutions from A using the fast greedy inclusion algorithm"""
    zmin = np.min(A, axis=0)
    zmax = np.max(A, axis=0)
    denom = zmax-zmin
    denom[denom == 0] = 1e-12
    Aprime = (A-zmin)/denom
    Diss = dissimilarityMatrix(Aprime, ppf)
    selected = [0]
    candidates = np.arange(1, len(A))
    Memo = Diss[candidates, selected]
    while len(selected) < N:
        best = np.argmin(Memo)
        Memo = Memo+Diss[candidates, candidates[best]]
        Memo = np.delete(Memo, best)
        selected.append(candidates[best])
        candidates = np.delete(candidates, best)
    return A[selected]

def fastGreedyRemovalAlgorithm(A, N, ppf):
    """Selects N solutions from A using the fast greedy removal algorithm"""
    zmin = np.min(A, axis=0)
    zmax = np.max(A, axis=0)
    denom = zmax-zmin
    denom[denom == 0] = 1e-12
    Aprime = (A-zmin)/denom
    Diss = dissimilarityMatrix(Aprime, ppf)
    selected = np.arange(0, len(A))
    Memo = np.sum(Diss, axis=1)
    while len(selected) > N:
        worst = np.argmax(Memo)
        Memo = Memo-Diss[selected,selected[worst]]
        Memo = np.delete(Memo, worst)
        selected = np.delete(selected, worst)
    return A[selected]

def fastSteadyStateRemovalAlgorithm(A, N, ppf):
    """Selects N solutions from A using the fast steady-state removal algorithm"""
    np.random.shuffle(A)
    zmin = np.min(A, axis=0)
    zmax = np.max(A, axis=0)
    denom = zmax-zmin
    denom[denom == 0] = 1e-12
    Aprime = (A-zmin)/denom
    Diss = dissimilarityMatrix(Aprime, ppf)
    selected = np.arange(0, N)
    candidates = np.arange(N, len(A))
    Memo = np.sum(Diss[:,selected][selected,:], axis=1)
    for candidate in candidates:
        Memo = Memo+Diss[selected,candidate]
        Memo = np.append(Memo, np.sum(Diss[candidate,selected]))
        selected = np.append(selected, candidate)
        worst = np.argmax(Memo)
        Memo = Memo-Diss[selected,selected[worst]]
        Memo = np.delete(Memo, worst)
        selected = np.delete(selected, worst)
    return A[selected]
